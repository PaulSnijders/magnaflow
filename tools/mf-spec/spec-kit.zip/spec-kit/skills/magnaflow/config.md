# `.magnaflow/config.yml`

The project's MagnaFlow config. It is committed and identical on every
machine, so it never holds machine paths or settings such as `git_sync`,
which live in each machine's own `magnaflow.yml`. mf-worker requires the
file. mf-run and the cockpit read only their own parts, and mf-watch
never reads it. Unknown keys are ignored.

```yaml
build:
  command: dotnet build App.sln     # or commands: [..], exactly one form
test:                               # optional: absent = no test gate
  commands:
    - dotnet test App.sln
    - npm --prefix web test
defaults:
  max_attempts: 3                   # optional, default 3
  command_timeout_minutes: 30       # optional, default 30
  agent_timeout_minutes: 30         # optional, default command_timeout_minutes
agent:
  command: claude                   # optional, default claude
  args: ["--permission-mode", "bypassPermissions"]
run:
  services: [...]                   # optional, below
  stable: {...}                     # optional, below
```

## `build` and `test`

`build` is required; `test` is optional. Each takes exactly one of
`command` (one string) or `commands` (a non-empty list, run in order, the
first failure stops). After every implementation attempt the worker runs
build then test. Red means another attempt, up to `max_attempts`, and
then the cmd is aborted.

**Without `test:`** the worker runs only the build and a green build
passes, so the agent owns the tests: its prompt tells it to run them and
make them pass before it finishes. That suits a slow suite the agent runs
anyway (it can fix a red test in place, where the gate can only start a
new attempt). The project's `CLAUDE.md` should then say how to run the
tests. An empty `test:` (a bare key, `commands: []`, a blank `command`)
is an error, not "off": only leaving the key out switches the gate off.

**Path-scoped commands.** In a monorepo, a `commands:` entry can be a
mapping with `run:` and `paths:`. It then runs only when the cmd touched
a file under one of those repo-relative prefixes. A string entry still
always runs.

```yaml
build:
  commands:
    - node more/cmd/mf-klaas-backend.js build    # string: always runs
    - run: npm --prefix topo run build
      paths: [topo/]                             # only when the cmd touched topo/
test:
  commands:
    - run: node more/cmd/mf-klaas-backend.js test
      paths: [klaas-backend/, more/cmd/mf-klaas-backend.js]
```

- A trailing `/` means a folder. A path without one is that file (or
  that folder): `topo` never matches `topology.md`. There are no globs.
- "Touched" means everything that differs from the cmd's claim commit:
  the run's commits, uncommitted changes, and untracked files that are
  not ignored. A rename counts both paths. The cmd's own lane files
  don't count.
- A skipped command counts as passed. When every test command is
  skipped, the attempt passes (`tests: all skipped, no touched paths`).
  A change to `.magnaflow/config.yml` itself runs every command.
- The agent's prompt lists which checks will run for its changes so far.
- `paths` exists only in `commands:` of `build`/`test`, not in the
  single `command:` form and not in actions.
- Invalid entries stop every run with exit 2: a missing `run`, an empty
  `paths`, an absolute path or `..`, or any key other than `run`/`paths`.
- **The mapping form needs a worker that knows it.** An older mf-worker
  fails on the config with a YAML error (exit 2, every cmd). Update the
  tools on every machine that runs this project first
  (self-update or `install.ps1`), then commit the mapping.

**Only commands that pass today.** A permanently red command makes every
cmd fail. Leave a broken suite out, and say so in a comment, until a cmd
fixes it. That holds per path too: a red check scoped to `topo/` fails
every cmd that touches `topo/`, even when the cmd did not break it.
Scoping does not make a broken check harmless; it only limits which cmds
it blocks. Never put anything here that deploys, installs or restarts the
MagnaFlow tools.

## `defaults`

- `max_attempts`: implementation attempts per cmd before it is aborted.
- `command_timeout_minutes`: the limit for each build or test command.
- `agent_timeout_minutes`: the limit for each agent invocation (the plan
  and every implementation attempt). Defaults to
  `command_timeout_minutes`; at least 1.
- Raising the agent timeout may need mf-watch's `worker_timeout_minutes`
  (machine config, default 120) raised too, since that bounds the whole run.

## `agent`

The CLI the worker runs for a cmd and for a `prompt` action. It runs
non-interactively, so nobody can answer a permission prompt. With
Claude Code's default mode every edit is refused and the agent
implements nothing. Set `args` to a permission mode that lets it work,
for example `["--permission-mode", "bypassPermissions"]`.

## `run.services`

The project's own long-running dev processes (a web server, a
background service). The worker stops them before a run so ports and
files are free, and starts them after it, so the fresh build is up.
A library or CLI project has none: leave `run:` out. That is the normal
case.

```yaml
run:
  services:
    - name: web                                    # unique, not "stable"
      command: src/App/bin/Debug/net10.0/App       # the built exe, not `dotnet run`
      args: ["--urls", "http://0.0.0.0:5000"]      # optional
      workdir: src/App                             # optional, default project root
      url: http://localhost:5000                   # optional, port check only
```

- **The built executable, never `dotnet run`**: that spawns a child and
  rebuilds on start, while the built exe is what the worker just
  produced and starts at once. Make sure the build produces that path.
- `command` and `workdir` both resolve against the project root.
- **Extensionless commands** keep one config valid on every OS. mf-run
  tries the literal path first, then `.cmd`, `.bat`, `.exe` (Windows) or
  `.sh` (Unix). Give a script both a `.cmd` and a `.sh`. The `.sh` is
  exec'd directly, so commit it executable:
  `git update-index --chmod=+x path/to/script.sh`.
- `url` only adds a "port listening" check to the cockpit's Run card.

By hand: `mf-run start|stop|restart|status [service]`.

## `run.stable`

An optional published build that a worker run never stops, on its own
port, so the human can keep using the app while the next cmd is built.
It is promoted after every cmd that ends `done` without a `branch:`,
and from the cockpit's **Promote** button (or `mf-run promote`).

```yaml
run:
  stable:
    publish: tools/mf-publish-stable   # resolved like a service command
    command: App                       # resolved inside the published dir
    args: ["--urls", "http://localhost:7300"]
    url: http://localhost:7300         # optional, port check
    link: https://host/app/            # optional, shown verbatim in the cockpit
    timeout_minutes: 15                # publish limit, default 15
```

The **`publish` script** gets one argument, the absolute output
directory, and runs in the project root. It must:

- publish a self-contained, runnable build into that directory (frontend
  included), so that `command` exists there;
- exit 0 on success and non-zero on failure;
- write nothing into the working tree. The worker's next run needs a
  clean tree.

Ship a `.cmd` and a `.sh`, as for services. The build runs with the
published directory as its workdir, not the repo. A failed publish, or a
build that does not start, leaves the previous instance running.
`.magnaflow/run/stable-publish.log` says why.
